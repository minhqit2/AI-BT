import cv2
import numpy as np
cap = cv2.VideoCapture('D:\python\pingpong\pingpong.mp4')

while(True):
    ret,frame=cap.read()
    blur = cv2.GaussianBlur(frame,(11,11),0)
    hsv = cv2.cvtColor(blur,cv2.COLOR_BGR2HSV)
    lower=np.array([5,100,20])
    upper = np.array([25,255,255])
    mask = cv2.inRange(hsv,lower,upper)
    mask = cv2.erode(mask,None, iterations=2)
    cv2.dilate(mask,None, iterations=2)
    cv2.imshow('mask',mask)
    cv2.imshow('frame',frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()